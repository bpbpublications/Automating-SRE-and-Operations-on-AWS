import json
from unittest import TestCase
from unittest.mock import Mock, patch, ANY
from app.app import analysis_func


class TestApp(TestCase):
    def test_analysis_func(self):
        # Create mock response body that matches the Messages API format
        mock_response_body = {
            'content': [{
                'text': 'Positive'
            }]
        }

        # Create mock response with body that can be read
        mock_body = Mock()
        mock_body.read.return_value = json.dumps(mock_response_body).encode()
        mock_response = {
            'body': mock_body
        }

        # Create mock Bedrock client
        mock_bedrock = Mock()
        mock_bedrock.invoke_model.return_value = mock_response

        # Mock boto3.client to return our mock Bedrock client
        with patch('boto3.client', return_value=mock_bedrock):
            result = analysis_func({'Review': 'Test review'})

            # Assert the final result
            assert result == 'Positive'

            # Assert that invoke_model was called once
            assert mock_bedrock.invoke_model.call_count == 1

            # Assert that the method was called with correct parameters
            mock_bedrock.invoke_model.assert_called_once_with(
                modelId='us.anthropic.claude-3-5-haiku-20241022-v1:0',
                body=ANY
            )

            # Verify the body content
            call_args = mock_bedrock.invoke_model.call_args
            body_arg = call_args[1]['body']
            body_json = json.loads(body_arg)
            assert 'messages' in body_json
            assert body_json['messages'][0]['role'] == 'user'
            assert 'Test review' in body_json['messages'][0]['content']
