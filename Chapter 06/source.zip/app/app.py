import logging
import boto3
import json
import traceback

import pandas as pd
import streamlit as st

from aws_xray_sdk.core import xray_recorder, patch_all


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Initialize X-Ray with error handling for missing daemon
xray_recorder.configure(service='ReviewSentimentAnalyzer')

# Patch all supported libraries
patch_all()

cloudwatch = boto3.client('cloudwatch', region_name='us-west-2')


def track_sentiment_metrics(sentiment):
    cloudwatch.put_metric_data(
        Namespace='ReviewAnalyzer',
        MetricData=[{
            'MetricName': 'SentimentDistribution',
            'Value': 1,
            'Unit': 'Count',
            'Dimensions': [
                {'Name': 'SentimentType', 'Value': sentiment}
            ]
        }]
    )


@xray_recorder.capture('analysis_func')
def analysis_func(row):
    try:
        logger.info("Initializing Bedrock client")
        brt = boto3.client(service_name='bedrock-runtime',
                           region_name='us-west-2')
        prompt = f"""
         You are an expert product reviewer and you can judge the sentiment of a
        review from how the review is stated. Analyze this product review and
        determine if the sentiment is positive, negative, or neutral.
        Return one word response, that says "Positive", "Negative" or "Neutral".
         Review: {row['Review']}
        """

        body = json.dumps({
            'messages': [{
                'role': 'user',
                'content': prompt
            }],
            'max_tokens': 4000,
            'anthropic_version': 'bedrock-2023-05-31'
        })
        logger.debug(f"Sending request to Bedrock model")
        response = brt.invoke_model(
            modelId='us.anthropic.claude-3-5-haiku-20241022-v1:0',
            body=body
        )
        if response:
            response_body = json.loads(response.get('body').read())
            return response_body.get('content')[0].get('text')
    except Exception as e:
        subsegment = xray_recorder.current_subsegment()
        if subsegment:
            subsegment.add_exception(e, traceback.format_exc())
        raise e


def clear_form():
    if 'form_submitted' in st.session_state:
        del st.session_state.form_submitted
        st.rerun()


def main():
    # Start a segment for the main application
    segment = xray_recorder.begin_segment('ReviewAnalyzerApp')

    # Log application startup
    logger.info("Starting Review Sentiment Analyzer application")

    st.title("Review Sentiment Analyzer")

    # Add custom annotation
    xray_recorder.put_annotation('application_name', 'ReviewAnalyzer')

    try:
        # Create tabs for different views
        tab1, tab2 = st.tabs(["Add Review", "Analyze Reviews"])

        with tab1:
            st.header("Add New Review")

            with st.form(key="review_form", clear_on_submit=True):
                product = st.text_input("Product Name")
                reviewer = st.text_input("Reviewer Name")
                review = st.text_area("Review", height=150)

                # Form submit button
                submitted = st.form_submit_button("Submit Review")

                if submitted:
                    try:
                        # Initialize DynamoDB resource
                        dynamodb = boto3.resource('dynamodb')
                        table = dynamodb.Table('DynamoProductTable')

                        # Add metadata for the review submission
                        xray_recorder.put_metadata('product_review', {
                            'product': product,
                            'reviewer': reviewer
                        })

                        # Insert item into DynamoDB
                        table.put_item(
                            Item={
                                'Product': product,
                                'Reviewer': reviewer,
                                'Review': review
                            }
                        )

                        # Show success message
                        st.success("Review added successfully!")

                        # Mark form as submitted
                        st.session_state.form_submitted = True

                        # Rerun the app to clear the form
                        st.rerun()

                    except Exception as e:
                        st.error(f"Error adding review: {str(e)}")
                        st.error(
                            "Please try again or contact support if "
                            "the error persists."
                        )
                        segment = xray_recorder.current_segment()
                        if segment:
                            segment.add_exception(e, traceback.format_exc())
                        raise
                    finally:
                        xray_recorder.end_segment()

            # Check if form needs to be cleared
            if 'form_submitted' in st.session_state:
                clear_form()

        with tab2:
            st.header("Product Reviews")

            # Add search box
            search_term = st.text_input("Search products:", placeholder="Enter product name to filter...")

            # Get items from DynamoDB
            items = get_dynamodb_items()

            if items:
                # Create a list to store the formatted data
                formatted_data = []

                # Format the data for display
                for idx, item in enumerate(items):
                    formatted_data.append({
                        'Product': item.get('Product', ''),
                        'Review': item.get('Review', ''),
                        'Sentiment': '',
                        'Analysis': idx
                    })

                # Convert to DataFrame
                df = pd.DataFrame(formatted_data)

                # Filter based on search term
                if search_term:
                    df = df[df['Product'].str.contains(search_term, case=False, na=False)]

                if len(df) > 0:
                    # Display each row with its button
                    for idx, row in df.iterrows():
                        # Create two columns for layout
                        col1, col2 = st.columns([3, 1])
                        # Display row data
                        with col1:
                            st.write(f"Product: {row['Product']}")
                            st.write(f"Review: {row['Review']}")
                        # Add button for this row
                        with col2:
                            if st.button(f'Analyze Sentiment', key=f'analyze_{idx}'):
                                sentiment = analysis_func(row)
                                if sentiment:
                                    # Track metrics for specific sentiments
                                    track_sentiment_metrics(sentiment)
                                    st.session_state[f'sentiment_{idx}'] = sentiment

                        # Display sentiment if it exists in session state
                        if f'sentiment_{idx}' in st.session_state:
                            st.write(
                                f"Sentiment: {st.session_state[f'sentiment_{idx}']}")
                        st.divider()  # Add a visual separator between rows
                else:
                    st.info(f"No products found matching '{search_term}'")

            else:
                logger.warning("No items retrieved from DynamoDB")
                st.warning("No items found in the database.")

    except Exception as e:
        error_msg = f"Error displaying product reviews: {str(e)}"
        logger.error(error_msg, exc_info=True)
        st.error("An error occurred while retrieving the product reviews.")
        segment = xray_recorder.current_segment()
        if segment:
            segment.add_exception(e, traceback.format_exc())
    finally:
        xray_recorder.end_segment()


@xray_recorder.capture('get_dynamodb_items')
def get_dynamodb_items():
    """
    Retrieve all items from DynamoDB table
    """
    try:
        # Initialize DynamoDB client
        logger.info("Initializing DynamoDB client")
        # Initialize dynamo db client for us-west-2 region
        boto3.setup_default_session(region_name='us-west-2')
        dynamodb = boto3.resource('dynamodb', region_name='us-west-2')
        table = dynamodb.Table('DynamoProductTable')

        # Scan the table
        logger.info("Scanning DynamoDB table")
        response = table.scan()
        items = response['Items']

        # Handle pagination if there are more items
        while 'LastEvaluatedKey' in response:
            logger.info("Retrieving additional items from table")
            response = table.scan(
                ExclusiveStartKey=response['LastEvaluatedKey'])
            items.extend(response['Items'])

        logger.info(f"Successfully retrieved {len(items)} items from DynamoDB")
        return items

    except Exception as e:
        subsegment = xray_recorder.current_subsegment()
        if subsegment:
            subsegment.add_exception(e, traceback.format_exc())
        logger.error(
            f"Error retrieving items from DynamoDB: {str(e)}", exc_info=True)
        return None


if __name__ == "__main__":
    main()
